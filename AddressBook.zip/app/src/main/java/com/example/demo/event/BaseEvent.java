package com.example.demo.event;


public class BaseEvent {
}
